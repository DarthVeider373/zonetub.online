// Flag para controlar se os links já foram configurados
let linksConfigured = false;

function setupLinks() {
    if (linksConfigured) return;

    if (typeof MONTHLY_REFILLS_LINK !== 'undefined' && 
        typeof BEST_VALUE_LINK !== 'undefined' && 
        typeof MOST_POPULAR_LINK !== 'undefined') {

        function preserveParams(element, newHref) {
            if (!element) return;
            if (element.dataset.processed === 'true') return;

            try {
                const currentUrl = new URL(window.location.href);
                const finalUrl = new URL(newHref);

                currentUrl.searchParams.forEach((value, key) => {
                    finalUrl.searchParams.set(key, value);
                });

                element.href = finalUrl.toString();
                element.dataset.processed = 'true';
            } catch (error) {
                console.error('Erro ao processar link:', error);
            }
        }

        ['1', '2', '3'].forEach(suffix => {
            const monthlyElement = document.getElementById('monthlyLink' + suffix);
            if (monthlyElement) preserveParams(monthlyElement, MONTHLY_REFILLS_LINK);
            
            const bestValueElement = document.getElementById('bestValueLink' + suffix);
            if (bestValueElement) preserveParams(bestValueElement, BEST_VALUE_LINK);
            
            const popularElement = document.getElementById('popularLink' + suffix);
            if (popularElement) preserveParams(popularElement, MOST_POPULAR_LINK);
        });

        const allLinks = document.querySelectorAll('a[href]');
        allLinks.forEach(link => {
            try {
                const href = link.getAttribute('href');
                if (href && !href.startsWith('javascript:') && !href.startsWith('#') && !link.dataset.processed) {
                    const currentUrl = new URL(window.location.href);
                    const finalUrl = new URL(link.href, currentUrl.origin);

                    currentUrl.searchParams.forEach((value, key) => {
                        finalUrl.searchParams.set(key, value);
                    });

                    link.href = finalUrl.toString();
                    link.dataset.processed = 'true';
                }
            } catch (error) {
                console.error('Erro ao processar link global:', error);
            }
        });

        linksConfigured = true;
    }
}

let animationStarted = false;

function startPulseAnimation() {
    if (animationStarted) return; 
    
    animationStarted = true;
    const btns = document.querySelectorAll('.best-value-btn');
    
    btns.forEach(btn => {
        btn.style.transition = 'transform 1s ease-in-out';
        
        setInterval(() => {
            btn.style.transform = 'scale(1.05)';
            setTimeout(() => {
                btn.style.transform = 'scale(1)';
            }, 1000);
        }, 2000);
    });
}

const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        if (mutation.type === 'attributes' && 
            mutation.attributeName === 'style' && 
            !linksConfigured) {
            setupLinks();
            startPulseAnimation();
        }
    });
});

window.addEventListener('load', () => {
    const elementoOculto = document.getElementById('elementoOculto');
    if (elementoOculto) {
        observer.observe(elementoOculto, {
            attributes: true,
            subtree: true,
            childList: true
        });
    }
    
    setupLinks();
    startPulseAnimation();
});

// ============================================
// QUIZ TRIGGER - Aparece aos 35:50 (2150 segundos)
// ============================================
let quizAlreadyShown = false;

function startQuizMonitoring() {
    if (typeof smartplayer === 'undefined' || !smartplayer.instances || !smartplayer.instances.length) {
        setTimeout(startQuizMonitoring, 1000);
        return;
    }

    const player = smartplayer.instances[0];
    
    if (!player.video) {
        setTimeout(startQuizMonitoring, 1000);
        return;
    }

    console.log('🎬 Quiz monitoring started - will show at 35:50 (2150 seconds)');

    // Monitora o tempo do vídeo
    player.on('timeupdate', () => {
        const currentTime = player.video.currentTime;
        
        // Debug a cada 30 segundos
        if (Math.floor(currentTime) % 30 === 0 && currentTime > 0) {
            console.log('⏱️ Video time:', Math.floor(currentTime), 'seconds');
        }
        
        // Mostra o quiz aos 35:50 (2150 segundos)
        if (currentTime >= 300 && !quizAlreadyShown) {
            quizAlreadyShown = true;
            console.log('🎯 Showing quiz at 35:50!');
            
            const quizSection = document.getElementById('quizSection');
            if (quizSection) {
                quizSection.style.display = 'block';
                setTimeout(() => {
                    quizSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 300);
            }
        }
    });

    // Verifica também ao dar play
    player.on('play', () => {
        if (player.video.currentTime >= 2150 && !quizAlreadyShown) {
            quizAlreadyShown = true;
            const quizSection = document.getElementById('quizSection');
            if (quizSection) {
                quizSection.style.display = 'block';
                setTimeout(() => {
                    quizSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }, 300);
            }
        }
    });
}

// ============================================
// ELEMENTO OCULTO (código original)
// ============================================
document.addEventListener("DOMContentLoaded", function() {
    var elementoOculto = document.getElementById('elementoOculto');
    var SECONDS_TO_DISPLAY = 0;
    var elementoJaMostrado = false;
    
    if (elementoOculto) {
        SECONDS_TO_DISPLAY = parseInt(elementoOculto.getAttribute('data-show-delay')) || 0;
    } else {
        return;
    }

    var storageKey = 'elementoMostrado_' + SECONDS_TO_DISPLAY;
    
    function showHiddenElement() {
        if (elementoJaMostrado) return;
        
        elementoOculto.style.display = "block";
        elementoOculto.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'start'
        });
        
        elementoJaMostrado = true;
        
        try {
            localStorage.setItem(storageKey, 'true');
        } catch (e) {
            // Ignora erros de localStorage
        }
    }

    function startWatchVideoProgress() {
        if (typeof smartplayer === 'undefined' || !smartplayer.instances || !smartplayer.instances.length) {
            setTimeout(startWatchVideoProgress, 1000);
            return;
        }

        const player = smartplayer.instances[0];
        
        if (!player.video) {
            setTimeout(startWatchVideoProgress, 1000);
            return;
        }

        player.on('timeupdate', () => {
            if (player.video.currentTime >= SECONDS_TO_DISPLAY) {
                showHiddenElement();
            }
        });

        player.on('play', () => {
            if (player.video.currentTime >= SECONDS_TO_DISPLAY) {
                showHiddenElement();
            }
        });
    }

    try {
        if (localStorage.getItem(storageKey) === 'true') {
            showHiddenElement();
        }
    } catch (e) {
        // Ignora erros de localStorage
    }

    setTimeout(startWatchVideoProgress, 1000);
    
    // ⚡ Inicia o monitoramento do quiz
    setTimeout(startQuizMonitoring, 1000);
});

// ============================================
// FUNÇÕES AUXILIARES
// ============================================
document.addEventListener('DOMContentLoaded', () => {
    const faqToggles = document.querySelectorAll('.faq-toggle');
    if (faqToggles) {
        faqToggles.forEach(toggle => {
            toggle.addEventListener('click', () => {
                const answer = toggle.nextElementSibling;
                const icon = toggle.querySelector('svg');
                
                if (answer && icon) {
                    answer.classList.toggle('hidden');
                    icon.classList.toggle('rotate-180');
                }
            });
        });
    }
    
    updatePublicationDate(); 
    updateViewerCount();
    startCountdown();
});

function updatePublicationDate() {
    const date = new Date();
    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    
    const dayName = days[date.getDay()];
    const monthName = months[date.getMonth()];
    const day = date.getDate();
    const year = date.getFullYear();

    const formattedDate = `${dayName}, ${day}  ${monthName} ${year}`;
    
    const dateElements = document.querySelectorAll('.publication-date');
    dateElements.forEach(element => {
        element.textContent = formattedDate;
    });
}

function updateViewerCount() {
    let num = 400;
    let increment = Math.floor(Math.random() * 2) + 2;
    let timer;
    
    const pessoasElement = document.getElementById('pessoasAssistindo');
    if (!pessoasElement) return;
    
    if (timer) {
        clearInterval(timer);
    }
    
    pessoasElement.textContent = num;
    
    timer = setInterval(function() {
        num += increment;
        pessoasElement.textContent = num;
        if (num >= 1500) {
            num = 602;
        }
        increment = Math.floor(Math.random() * 2) + 2;
    }, 2000);
}

function startCountdown() {
    const countdownElements = document.querySelectorAll('.countdown-timer');
    if (!countdownElements.length) return;

    countdownElements.forEach(countdownElement => {
        if (window.getComputedStyle(countdownElement).display === 'none') return;

        if (countdownElement.dataset.timer) {
            clearInterval(parseInt(countdownElement.dataset.timer));
        }

        let minutes = 16;
        let seconds = 42;

        function updateDisplay() {
            const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
            countdownElement.textContent = formattedTime;
        }

        const timer = setInterval(() => {
            if (seconds === 0) {
                if (minutes === 0) {
                    clearInterval(timer);
                    minutes = 16;
                    seconds = 42;
                    updateDisplay();
                    startCountdown();
                    return;
                }
                minutes--;
                seconds = 59;
            } else {
                seconds--;
            }
            updateDisplay();
        }, 1000);

        countdownElement.dataset.timer = timer;
        updateDisplay();
    });
}

function toggleFAQ(id) {
    const answer = document.querySelector(`#faq-${id}`);
    const icon = document.querySelector(`#faq-icon-${id}`);
    
    if (answer.classList.contains('hidden')) {
        answer.classList.remove('hidden');
        answer.classList.add('block');
        icon.classList.remove('fa-plus');
        icon.classList.add('fa-minus');
    } else {
        answer.classList.add('hidden');
        answer.classList.remove('block');
        icon.classList.add('fa-plus');
        icon.classList.remove('fa-minus');
    }
}

// ============================================
// QUIZ LOGIC
// ============================================
const quizData = {
    age: '',
    weight: '',
    duration: '',
    glucose: '',
    symptoms: []
};

let currentQ = 1;

function setupQuizOptions(questionNum, buttonId) {
    const options = document.querySelectorAll(`#question${questionNum} .quiz-option:not(label)`);
    const button = document.getElementById(buttonId);
    
    if (!options.length || !button) return;
    
    options.forEach(option => {
        option.addEventListener('click', function() {
            options.forEach(o => {
                o.classList.remove('border-red-500', 'bg-red-500', 'text-white', 'shadow-xl');
                o.classList.add('border-gray-200', 'bg-white');
            });
            this.classList.remove('border-gray-200', 'bg-white');
            this.classList.add('border-red-500', 'bg-red-500', 'text-white', 'shadow-xl');
            
            const dataKey = ['age', 'weight', 'duration', 'glucose'][questionNum - 1];
            quizData[dataKey] = this.dataset.value;
            button.disabled = false;
        });
    });
}

function initQuizLogic() {
    setupQuizOptions(1, 'btn1');
    setupQuizOptions(3, 'btn3');
    setupQuizOptions(4, 'btn4');

    // Weight input handler
    const weightInput = document.getElementById('weightInput');
    const btn2 = document.getElementById('btn2');

    if (weightInput && btn2) {
        weightInput.addEventListener('input', function() {
            const weight = parseInt(this.value);
            if (weight >= 50 && weight <= 500) {
                quizData.weight = weight;
                btn2.disabled = false;
            } else {
                btn2.disabled = true;
            }
        });
    }

    // Checkboxes handler
    const checkboxes = document.querySelectorAll('.symptom-checkbox');
    const btn5 = document.getElementById('btn5');

    if (checkboxes.length && btn5) {
        checkboxes.forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                quizData.symptoms = Array.from(checkboxes)
                    .filter(cb => cb.checked)
                    .map(cb => cb.value);
                
                btn5.disabled = quizData.symptoms.length === 0;
            });
        });
    }

    // Navigation buttons
    const btn1 = document.getElementById('btn1');
    const btn3 = document.getElementById('btn3');
    const btn4 = document.getElementById('btn4');

    if (btn1) btn1.addEventListener('click', () => goToQuestion(2));
    if (btn2) btn2.addEventListener('click', () => goToQuestion(3));
    if (btn3) btn3.addEventListener('click', () => goToQuestion(4));
    if (btn4) btn4.addEventListener('click', () => goToQuestion(5));
    if (btn5) btn5.addEventListener('click', showLoading);
}

function goToQuestion(num) {
    const currentQuestion = document.getElementById(`question${currentQ}`);
    const nextQuestion = document.getElementById(`question${num}`);
    const headline = document.getElementById('quizHeadline');
    
    if (currentQuestion) currentQuestion.classList.add('hidden');
    if (nextQuestion) nextQuestion.classList.remove('hidden');
    
    if (num > 1 && headline) {
        headline.classList.add('hidden');
    }
    
    currentQ = num;
}

function showLoading() {
    const question5 = document.getElementById('question5');
    const loadingScreen = document.getElementById('loadingScreen');
    
    if (question5) question5.classList.add('hidden');
    if (loadingScreen) loadingScreen.classList.remove('hidden');

    const steps = ['step1', 'step2', 'step3', 'step4'];
    let delay = 0;

    steps.forEach((stepId, index) => {
        setTimeout(() => {
            const step = document.getElementById(stepId);
            if (step) {
                step.classList.remove('opacity-30', 'border-transparent');
                step.classList.add('opacity-100', 'bg-white', 'shadow-lg', 'border-[#4DD0D3]', 'translate-x-2');
            }
            
            if (index === steps.length - 1) {
                setTimeout(() => {
                    const quizSection = document.getElementById('quizSection');
                    const productSection = document.getElementById('productSection');
                    
                    if (quizSection) quizSection.style.display = 'none';
                    if (productSection) productSection.style.display = 'block';
                    
                    setTimeout(() => {
                        scrollToProducts();
                    }, 300);
                }, 800);
            }
        }, delay);
        delay += 1250;
    });
}

function scrollToProducts() {
    const productSection = document.getElementById('productSection');
    if (productSection) {
        productSection.scrollIntoView({behavior: 'smooth', block: 'start'});
    }
}

// Inicializa a lógica do quiz quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    initQuizLogic();
});